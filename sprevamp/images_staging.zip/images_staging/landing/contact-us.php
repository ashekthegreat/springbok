<?
	session_start();
	include("utils.php");

	
	$sql_content = "select meta_title,page_keywords, page_description,h_title from ".WEBPAGES." where page_url='contact-us'";
	$res=mysql_query($sql_content);
	$rc=mysql_fetch_array($res);
	
	dhtml("main();",$rc[0],$rc[1],$rc[2]);
	function main()
	{
?>
<?php
	$sql_content = "select h_title from ".WEBPAGES." where page_url='contact-us'";
	$res=mysql_query($sql_content);
	$rc=mysql_fetch_array($res);
?>

<table border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td align="left" class="page-header"><?=$rc[0]?>
      <div style="float:right; vertical-align:baseline;"  > <a href="http://www.yellowspringbok.co.uk/support/" target="_blank" style="font-size:16px;font-weight:bold;" >Submit Support Ticket</a> </div></td>
  </tr>
  <tr><td>&nbsp;</td></tr>
  <tr>
    <td><table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr><td align="left" colspan="2"> We are committed to provide excellent solutions for fast house sale. Our consultants and dedicated Case Managers are available during office hours and up to 8PM (by appointment), to offer free professional guidance to help sell your house fast. </td></tr>
        <tr><td colspan="2">&nbsp;</td></tr>
        <tr><td align="left" colspan="2"> For an instant no-obligation cash offer for your house, please fill in the contact form to your right. </td></tr>
        <tr><td colspan="2">&nbsp;</td></tr>
        <tr><td align="left" colspan="2"> For other enquiries, please feel free to raise a <a href="http://www.yellowspringbok.co.uk/support/" target="_blank" style="font-size:16px;font-weight:bold;" >support ticket</a> and a member of our team will contact you. Your data is safe with us. We are a Data Protection Registered Business with <b>registration number Z249589X </b> </td></tr>
        <tr><td colspan="2" class="head-small2">&nbsp;</td></tr>
        <tr><td colspan="2">&nbsp;</td></tr>
        <tr>
          <td align="left" valign="top"><table width="80%" cellpadding="0" cellspacing="0" border="0">
              <tr>
                <td align="left" valign="top">Phone</td>
                <td align="left" valign="top">:&nbsp;0800 068 7040<br />
                  &nbsp;&nbsp;0333 200 8636 (Mobile Friendly) </td>
              </tr>
              <tr><td colspan="2"><img src="images/spacer.gif" alt="" height="10" /></td></tr>
              <tr>
                <td align="left" valign="top">Fax</td>
                <td align="left" valign="top">:&nbsp;0845 862 2081 </td>
              </tr>
            </table></td>
          <td align="left" valign="top" class="green-text">&nbsp;</td>
        </tr>
        <tr><td colspan="2" class="head-small2">&nbsp;</td></tr>
        <tr><td colspan="2" height="10"><img src="images/spacer.gif" alt="" height="10" /></td></tr>
      </table></td>
  </tr>
  <tr>
    <td><table width="100%" cellpadding="0" cellspacing="0" border="0">
        <tr>
			<td class="heading-main" width="52%"> Head Office Address </td>
			<td rowspan="2" align="right" valign="top" width="48%">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr><td><img src="images/new-ofc.jpg" alt="head office" /></td></tr>
				</table>
			</td>
		</tr>
        <tr>
          <td align="left" valign="top">
		  <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td align="left" valign="top" style="padding:8px 8px 15px 8px;"><font color="#000000"><b>Yellow Springbok</b><br />
                  Unit A8<br />
                  Baird House Business Centre<br />
                  Liverpool Innovation Park<br />
                  Edge Lane<br />
                  Liverpool<br />
                  L7 9NJ</font><br />
                  <br />
                </td>
              </tr>
            </table>
		  </td>
        </tr>
      </table></td>
  </tr>
  <tr><td align="left" valign="top">&nbsp;</td></tr>
  <tr><td class="heading-main"><!--<img src="images/orange-bar.jpg" alt="" />--> Google Map</td></tr>
  <tr>
    <td align="left" valign="top">
		<div id="DHTMLgoodies_largeImage" style="margin:0px auto; padding:0px;">
        <table border="0">
          <tr><td align="center" valign="middle" class="photo-details"><div id="mapBig" style="width:720px;height:270px;color:#000000"> </div></td></tr>
        </table>
		</div></td>
  </tr>
  <tr><td align="left" valign="top"><img src="images/spacer.gif" alt="" width="1" height="20" /> </td></tr>
</table>
<?php
	$address = 	'Liverpool, Suite 17-18 Back Dovecot Place L14 9BA UK';	
	include_once("map.js.php");
?>
<script type="text/javascript">


$(document).ready(function () {
    initialize();
	showAddress('Liverpool Innovation Park, Edge Ln, Liverpool, L7 9NJ, UK');
});
//GUnload();
</script>
<?
	}
?>
