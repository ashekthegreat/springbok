	<?php	
		#############################################################
		
				$parent_id = '';
				$area_path = "";
				
				$url = $_SERVER['REQUEST_URI'];
				$url = substr($url,strrpos($url,"/")+1);
				$url = str_replace(".html","",$url);
			##############################################
				$urlArr =  explode("/",$_SERVER['REQUEST_URI']);
				
				$sql = "SELECT page_url FROM ".WEBPAGES;
				$rs = mysql_query($sql) or die(mysql_error().$sql);
				$tabArr = array();
				while($rec = mysql_fetch_assoc($rs))
				{
					$tabArr[] = $rec['page_url'];
				}
			
				//print_r($tabArr);
				/*$tabArr = array(
								'about-us',
								'free-resources',
								'our-services',
								'instant-offer',
								'sales-application-form',
								'testimonials',
								'stop-repossession',
								'fast-house-sale-benefits',
								'frequently-asked-questions',
								'commercial-property-wanted',
								'land-wanted',
								'fast-house-sale-benefits',
								);*/
				$getCont = '';
				foreach($tabArr as $key=>$pageUrl)
				{
					if (in_array($pageUrl, $urlArr)) 
					{
						$sql = "SELECT id FROM ".WEBPAGES." WHERE page_url = '".$pageUrl."'";
						$rs = mysql_query($sql) or die(mysql_error().$sql);
						$rec = mysql_fetch_assoc($rs);
						$parent_id = $rec['id'];
						$sub_url = $url;
						$url = $pageUrl;
						if(!empty($_SESSION["area"]))
						{
							$area_path = "/".$_SESSION["area"]; 	
						}
						$getCont = true;
					}	
				} 
			##############################################	
				if(!$getCont)
				{
							$sql = "SELECT page_url FROM ".AREA_CONTENT;
							$rs = mysql_query($sql) or die(mysql_error().$sql);
							$tabArr = array();
							while($rec = mysql_fetch_assoc($rs))
							{
								$tabArr[] = $rec['page_url'];
							}
							
							foreach($tabArr as $key=>$pageUrl)
							{
								if (in_array($pageUrl, $urlArr)) 
								{
									$sql = "SELECT id FROM ".WEBPAGES." WHERE page_url = '".$pageUrl."'";
									$rs = mysql_query($sql) or die(mysql_error().$sql);
									$rec = mysql_fetch_assoc($rs);
									$parent_id = $rec['id'];
									$sub_url = $url;
									$url = $pageUrl;
									if(!empty($_SESSION["area"]))
									{
										$area_path = "/".$_SESSION["area"]; 	
									}
									$getCont = true;
								}	
							}	
				}


		#################################################################
		?>