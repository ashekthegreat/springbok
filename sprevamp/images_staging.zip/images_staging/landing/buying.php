<?php
	session_start();
	include("utils.php");
	//include("includes/functions.php");
	$meta_title = "Join Us";
	$meta_description = "Join us - Fast Property Solutions";
	$meta_keywords = "register,join us,join";
	$right_sidebar = false;

	dhtml("main();", $meta_title, $meta_description, $meta_keywords, $right_sidebar);
	
	function main() {
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td height="15"></td>
  </tr>
  <tr>
    <td>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="400" align="left" valign="bottom"><img src="images/price-to-sell.png" width="394" height="163" vspace="20" alt="" /></td>
        <td width="30">&nbsp;</td>
        <td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td align="left" valign="middle"><img src="images/heading.png" alt="" /></td>
            </tr>
            <tr>
              <td align="left" valign="middle" height="30"><strong>We get loads! Search our list for great deals available right now!</strong></td>
            </tr>
            <tr>
              <td align="left" valign="middle">&nbsp;</td>
            </tr>
            <tr>
              <td align="left" valign="middle" class="headingtxt">Can't find what you'r looking for?</td>
            </tr>
            <tr>
              <td align="left" valign="middle" class="headingtxt">Call us today - we'll find it for you!</td>
            </tr>
            <tr>
              <td align="left" valign="middle">&nbsp;</td>
            </tr>
            <tr>
              <td align="left" valign="middle"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="50">&nbsp;</td>
                    <td width="50"><img src="images/phone-icon.png" width="44" height="44" /></td>
                    <td align="left" class="headingtxt" valign="middle">0800 068 7040</td>
                  </tr>
              </table></td>
            </tr>
        </table></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td width="30" align="right" valign="bottom" bgcolor="#eeeeee">&nbsp;</td>
        <td class="find-animation-bg" align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="400" align="right" valign="bottom" height="150"></td>
            <td width="30">&nbsp;</td>
            <td align="right" valign="middle"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td align="right" valign="middle" class="search-bg"><table width="400" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td align="left" valign="middle"><input type="text" name="search-bx" value="" id="search-bx" /></td>
                        <td align="center" valign="middle"><input type="image" src="images/search-button.png" alt="Search" title="" /></td>
                      </tr>
                  </table></td>
                </tr>
            </table></td>
          </tr>
        </table></td>
      </tr>
      
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td align="center" valign="top"><table width="80%" border="0" cellpadding="0" cellspacing="0" bgcolor="#000000">
      <tr>
        <td colspan="2" align="center" valign="middle"><img src="images/typical-propertis.png" alt="" vspace="20" title="" /></td>
        </tr>
      
      <tr>
        <td colspan="2" align="center" valign="top"><table width="90%" border="0" cellpadding="5" cellspacing="0" class="search-property-block">
          <tr>
            <td width="210" align="left" valign="top"><img src="images/house1.png" alt="" title="" /><div class="status-sold-stc"></div></td>
            <td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="60" align="left" valign="middle" class="prop-heading-name">3 bedroom semi detached house in Liverpool</td>
              </tr>
              <tr>
                <td height="85" align="left" valign="bottom" class="prop-details">Valued at &#163;148,000<br/>
                  Priced to sell with a Discount of &#163;50,000</td>
              </tr>
            </table></td>
          </tr>
          
        </table></td>
        </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td colspan="2" align="center" valign="top"><table width="90%" border="0" cellpadding="5" cellspacing="0" class="search-property-block">
            <tr>
              <td width="210" align="left" valign="top"><img src="images/house2.png" alt="" title="" /><div class="status-sold"></div></td>
              <td align="left" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="60" align="left" valign="middle" class="prop-heading-name">3 bedroom semi detached house in Liverpool</td>
                </tr>
                <tr>
                  <td height="85" align="left" valign="bottom" class="prop-details">Valued at &#163;148,000<br/>
                    Priced to sell with a Discount of &#163;42,000</td>
                </tr>
              </table></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td colspan="2" align="center" valign="top">&nbsp;</td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>	</td>
  </tr>
</table>
<?php } ?>
