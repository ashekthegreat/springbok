<?php

// 20002024 73be38xd 
// blog admin Ur5v#Hj2Jkqx

 
	  // ----------------------------------- stop insert attacks
  foreach ($_REQUEST as $key=>$value)
    {
    if (get_magic_quotes_gpc()==0)
       {
       $value = addslashes(htmlspecialchars(trim($value)));
       }
    }
     // ----------------------------------- stop insert attacks
	 
	 include("includes/config.php"); 
	 
	 // -------------- postcode checker

if ($_POST[post_code_check] == 'active')
         { // postcode checker active		 
	$postcode_search = substr("$_POST[post_code]", 0, 2);  
	$postcode_search = trim(eregi_replace("[[:punct:]]| |[0-9]", "", $postcode_search));
	$result_postcode = MYSQL_QUERY("SELECT town_name FROM ".POSTCODE."  WHERE post_code LIKE '$postcode_search' LIMIT 1 ");	 
	$row_postcode = mysql_fetch_array($result_postcode);
	
	if ($row_postcode["town_name"] != '') { // yes town selected
	 $remove_chars = array(" ",);
	 $town_dashed = trim(str_replace($remove_chars, "-", $row_postcode["town_name"]));
	 header("Location: ../".strtolower($town_dashed).".html" );
	 
	} // yes town selected
	 
		 } // postcode checker active

// -------------- postcode checker
//print_r($_SERVER);
//print_r($_REQUEST);
$this_url = strtolower($_ENV["REQUEST_URI"]); // domain 
$this_url_a = explode("?", $this_url);
$this_url_b = explode("/", $this_url_a[0]);
// $this_url_b = array_reverse($this_url_b);
if ($this_url_b[2] != '') { $find_area = strtolower(trim($this_url_b[2])); }
else { $find_area = strtolower(trim($this_url_b[1])); }
$find_area = strtolower(trim($_REQUEST['url']));
$remove_chars = array(".html", "-", );			 
$new_chars = array(" ", " ", );		   
$find_area = trim(str_replace($remove_chars, $new_chars, $find_area));
//echo $find_area."::::::::::::::::::".$display_area_name;
	// ----------------------- find town info
	if ( $find_area != '')
	      { //  if it looks like a town name ...
$result_find_area = MYSQL_QUERY("SELECT town_name FROM ".POSTCODE." WHERE town_name LIKE '$find_area' LIMIT 1 ");	
 $row_find_area = mysql_fetch_array($result_find_area);
 if ($row_find_area["town_name"] != '') 
          { // check to see if its in the postcode list
	$town_name_search = $row_find_area["town_name"]; 
	      } // check to see if its in the postcode list
        else 
		  { // else check to see if its still in the areas list
$town_name_search_a = strtolower(trim($find_area));	
$result_town_name_a = MYSQL_QUERY("SELECT area_name FROM ".AREAINFO."  WHERE area_name = '$town_name_search_a' LIMIT 1 ");  
	$row_town_info_a = mysql_fetch_array($result_town_name_a);
	$town_name_search = $row_town_info_a["area_name"]; 
		  } // check to see if in the areas list
	
	 if ( $town_name_search != '')
            { // only show areas in on town page	
$show_area_name = 'on';				
$town_name_search = strtolower(trim($town_name_search));		
$result_town_info = MYSQL_QUERY("SELECT * FROM ".AREAINFO."  WHERE area_name = '$town_name_search' LIMIT 1 ");
$row_town_info = mysql_fetch_array($result_town_info);
$page_keywords = $page_keywords.$row_town_info["area_keywords"];

           } // only show areas in on town page
		  else
		   { // select the region name if its not a town
$result_region = MYSQL_QUERY("SELECT region_name FROM ".AREAINFO."  WHERE region_name LIKE '$find_area' LIMIT 1 ");
$row_region = mysql_fetch_array($result_region);
$full_region_name = $row_region["region_name"];
if ($town_name_search == '') { $town_name_search = $full_region_name; }
		   } // select the region name if its not a town
		   
	      } // if it looks like a town name ...
	// ---------------------- find town info

$date_now = date("YmdHis"); 

if ($town_name_search != '') { $add_to_title = ' '.ucwords($town_name_search); $display_area_name = $town_name_search;}
else if ($full_region_name != '') { $add_to_title = ' '.ucwords($town_name_search); $display_area_name = $full_region_name;}
if ($page_keywords != '') { $add_to_keywords = ' '.$page_keywords; }

	 $base_url = BASE_URL;
	 $links_url = 'http://'.$base_url;
	 $website_name = 'Fast Property Investments';
	 
if ($display_area_name != '') 
     { 
$remove_chars = array(" ",  );			 
$new_chars = array("-", );		   
$display_area_name_dashed = trim(str_replace($remove_chars, $new_chars, $display_area_name)); 
	 $area_link_text = "/". $display_area_name_dashed; 
	 }
	 
$page_title = $page_title.$add_to_title.' - '.$website_name;
$page_description = $page_description.$add_to_title.$add_to_keywords.' - '.$website_name;
$page_keywords = $page_keywords.$add_to_title.$add_to_keywords.' - '.$website_name;
$h_title = $h_title.$add_to_title.' - '.$website_name;
//echo "::::::::::::::::::".$display_area_name;
//exit;
 ?>

